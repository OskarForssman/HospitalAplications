package com.example.comtest;


import android.os.AsyncTask;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.UnknownHostException;

public class Client extends AsyncTask<Void, Void, String> {

    String dstAddress;
    int dstPort;
    Socket client=null;
    String textResponse;

    Client(String addr, int port, String textResponse) {
        dstAddress = addr;

        dstPort = port;
        this.textResponse = textResponse;
    }

    @Override
    protected String doInBackground(Void... arg0) {
            try {

                System.out.println("XXX");
                Thread thread = new Thread(new Runnable() {
                    public void run() {

                        try {
                            client = new Socket(InetAddress.getByName(dstAddress),dstPort);
                            System.out.println("Client socket is created " + client);
                            //Upp 1 YES/NO
                            OutputStream clientOut = client.getOutputStream();
                            PrintWriter pw = new PrintWriter(clientOut, true);
                            pw.println(textResponse);

                            //Upp 1 YES/NO
                           InputStream clientIn = client.getInputStream();
                            BufferedReader br = new BufferedReader(new InputStreamReader(clientIn));
                                 System.out.println("Message returned from the server = " + br.readLine());

                           pw.close();
                            br.close();
                            client.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
                thread.start();

    }catch (Exception e){

            }
        return textResponse;
    }

}