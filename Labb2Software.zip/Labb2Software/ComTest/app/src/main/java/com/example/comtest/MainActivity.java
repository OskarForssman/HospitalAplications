package com.example.comtest;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;

public class MainActivity extends AppCompatActivity {

    boolean hop=true;
    boolean dop=true;
    boolean top=true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        final Button YES= findViewById(R.id.YES);
        final Button NO= findViewById(R.id.NO);
        final Switch window=findViewById(R.id.switchWindow);
        final Switch lamp=findViewById(R.id.switchLAMP);
        final Switch door=findViewById(R.id.switchDOOR);

        final TextView windowtext=findViewById(R.id.textView);
        final TextView lamptext=findViewById(R.id.textView);
        final TextView doortext=findViewById(R.id.textView);








        YES.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {

        Client client=new Client("85.197.159.223",80,"YES");
        client.doInBackground();
    }
      });
        NO.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Client client=new Client("85.197.159.223",80,"NO");
                client.doInBackground();
            }
        });

        window.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (top==true){
                    JSONObject obj=json(hop,dop,top);
                    Client client=new Client("85.197.159.223",80,obj.toString());
                    client.doInBackground();
                    windowtext.setText(obj.toString());
                    top=false;
                }else if (top==false){
                    JSONObject obj=json(hop,dop,top);
                    Client client=new Client("85.197.159.223",80,obj.toString());
                   client.doInBackground();
                    windowtext.setText(obj.toString());
                    top=true;
                }

            }
        });
        lamp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (dop==true){
                    JSONObject obj=json(hop,dop,top);
                    Client client=new Client("85.197.159.223",80,obj.toString());
                    client.doInBackground();
                    lamptext.setText(obj.toString());
                    dop=false;
                }else if (dop==false){
                    JSONObject obj=json(hop,dop,top);
                    Client client=new Client("85.197.159.223",80,obj.toString());
                    client.doInBackground();
                    lamptext.setText(obj.toString());
                    dop=true;
                }


            }
        });
        door.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (hop==true){
                    JSONObject obj=json(hop,dop,top);
                    Client client=new Client("85.197.159.223",80,obj.toString());
                    client.doInBackground();
                    doortext.setText(obj.toString());
                    hop=false;
                }else if (hop==false){
                    JSONObject obj=json(hop,dop,top);
                    Client client=new Client("85.197.159.223",80,obj.toString());
                    client.doInBackground();
                    doortext.setText(obj.toString());
                    hop=true;
                }

            }
        });


    }
    public JSONObject json(boolean a,boolean b,boolean c){
        final JSONObject obj=new JSONObject();
        try {
            obj.put("LAMP",a);
            obj.put("DOOR",b);
            obj.put("WINDOW",c);

        } catch (JSONException e) {
            e.printStackTrace();
        }
return obj;
    }
}
