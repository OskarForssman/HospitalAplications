package com.example.server;

import android.os.AsyncTask;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;

    public class Server extends AsyncTask<Void, Void, String> {
String dstAddress;
int dstPort;
        ObjectInputStream is;

        Server(String addr, int port) {
            dstAddress = addr;
            dstPort = port;
        }

        @Override
        protected String doInBackground(Void... arg0) {


            ServerSocket serverSocket = null;
            try {
                serverSocket = new ServerSocket();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try
                {

                    serverSocket= new ServerSocket(dstPort,1, InetAddress.getByName(dstAddress));
                }
                catch (IOException e)
                {
                    System.out.println("Could not listen on port: 80");
                }
                Socket clientSocket = null;
                try {
                    clientSocket = serverSocket.accept();
                }
                catch (IOException e) {
                    System.out.println("Accept failed: 80");
                }
            try {

                ObjectInputStream is=new ObjectInputStream(clientSocket.getInputStream());
                if(is==null){

                }else if (is!=null){
                    try {
                        is = (ObjectInputStream) clientSocket.getInputStream();
                    } catch (IOException e) {
                        System.out.println(e);
                    }
                }


            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                String s= String.valueOf(is.read());
            } catch (IOException e) {
                e.printStackTrace();
            }

            return "Workin";
        }



    }
