package com.example.server;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final Button search= findViewById(R.id.look);









        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Server server=new Server("85.197.159.223",80);
                String s= server.doInBackground();
                System.out.println("XXX:"+s);
            }
        });




    }



            }







